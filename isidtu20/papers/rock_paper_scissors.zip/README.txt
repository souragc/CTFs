one, two, three... rock, paper, scissors... pwned!

nc 40.121.22.147 12345 OR nc 40.117.63.62 12345