pyinstaller --onefile main.py
