using Pkg


pkg"add https://github.com/faf0/AES.jl"
#pkg"rm AES"
pkg"add https://github.com/oxinabox/MD5.jl"
pkg"add JSON"
