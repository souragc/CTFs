<html>
<body>
<h1>Kek</h1>
{{ $img }}
</body>
</html>
