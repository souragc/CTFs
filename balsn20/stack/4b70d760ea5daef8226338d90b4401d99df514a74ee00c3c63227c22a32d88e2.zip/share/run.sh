#!/bin/sh

exec 2>/dev/null
timeout 600 /home/STACK/stack
