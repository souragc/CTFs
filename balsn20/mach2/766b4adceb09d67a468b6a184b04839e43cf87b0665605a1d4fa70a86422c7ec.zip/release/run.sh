#!/bin/bash

CURDIR=`pwd`
sandbox-exec -f $CURDIR/machbookpro.sb $CURDIR/machbookpro
