# IL

1. [Install .NET Core Runtime 3.1](https://docs.microsoft.com/en-us/dotnet/core/install/linux-ubuntu)
2. Run `il` and cast your spell

friendly note: there are no intended bugs in `il`
