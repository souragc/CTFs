#!/bin/sh
cd /home/ctf/
timeout 60 /home/ctf/chall

